var config = {
	host: window.location.hostname,
	prefix: window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 ),
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
require.config( {
	baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources"
} );
require( ["js/qlik"], ( qlik ) => {
	qlik.on( "error", ( error ) => {
    $( '#popupText' ).append( error.message + "<br>" );
    $( '#popup' ).fadeIn( 1000 );
  } );
  $( "#closePopup" ).click( () => {
    $( '#popup' ).hide();
  } );
// JavaScript
	//open apps -- inserted here --
	var app = qlik.openApp('a2b1e6b5-3c51-4d04-96e8-d501587ba76d', config);



	//get objects -- inserted here --
	app.getObject('QV04','aRbgR');
	app.getObject('QV03','TLAyz');
	
	app.getObject('QV02','RHeJG');
	app.getObject('QV01','bWzh');
});